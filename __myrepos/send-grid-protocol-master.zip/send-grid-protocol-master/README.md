# Send Grid Protocol

[![Build Status](https://travis-ci.org/elpete/send-grid-protocol.svg?branch=master)](https://travis-ci.org/elpete/send-grid-protocol)

## A [`cbmailservices`](https://github.com/ColdBox/cbox-mailservices) protocol for sending email via Send Grid


